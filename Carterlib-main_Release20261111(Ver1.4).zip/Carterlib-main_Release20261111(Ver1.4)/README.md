# carterlib

<img width="720" alt="image" src="https://github.com/user-attachments/assets/f86da875-1947-4e8a-bd73-1981298901d9" />
<p><p>

<img width="360" alt="image" src="https://github.com/user-attachments/assets/dbb325da-1946-4695-a5fb-abbf615aa675" />
<img width="360" alt="image" src="https://github.com/user-attachments/assets/75821c07-ac90-436b-a007-b0e684745b8c" />
<p>
  
<img width="360" alt="image" src="https://github.com/user-attachments/assets/f82fd559-f0be-45a2-9c6a-f1503e851d56" />
<img width="360" alt="image" src="https://github.com/user-attachments/assets/81c0204f-56f1-48d2-bc96-639008a274b1" />



## Update History

* ver.1.4 Release (2026/11/10)
   * Add I2C module configuration for "MT6701 Angle Sensor" (14-bit magnetic absolute encoder)
* ver.1.3 Release (2026/11/03)
   * Add I2C module configuration for "AS5048B Angle Sensor" (14-bit magnetic absolute encoder)
* ver.1.2 Release (2026/03/29)
   * Use basic Simulink blocks instead of a MATLAB Function for the "AS5601 Angle Sensor"
   * Change default "Sample Time" of "I2C Read" from 0.005s to -1 (-1 for inherited) 
* ver.1.1 Release (2026/03/19)
   * Add I2C module configuration for "AS5601 Angle Sensor" (12-bit magnetic absolute encoder)
* ver.1.0 Release (2026/01/05)

Previous versions are available here:
https://github.com/Prof-Carter/Carterlib_Release

## Citation / Usage Notice

If you use this library in a research presentation, paper, or educational material,
please include the following link as a reference:

Masakatsu Kawata: https://github.com/Prof-Carter/Carterlib

## Overview
Simulink library "carterlib" provides a set of Simulink blocks.  
* Motor driver DRV8833
* Angle sensor (12-bit magnetic absolute encoder: I2C device) AS5601
* Angle sensor (14-bit magnetic absolute encoder: I2C device) AS5048B
* Angle sensor (14-bit magnetic absolute encoder: I2C device) MT6701

## Supported Versions
- MATLAB/Simulink R2023a or later

## Installation
1. Extract the downloaded files to any folder, for example:
C:\hoge\Carterlib-main

2. Add the folder path to MATLAB using:  
```
>> addpath('C:\hoge\Carterlib-main')
>> carterlib
```

## Disclaimer

This library is intended for research and educational purposes only.
The author assumes no responsibility for any damage or loss caused by its use.

## License

MIT License
(See the LICENSE file for details)

© 2026 Masakatsu Kawata
